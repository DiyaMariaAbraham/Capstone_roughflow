//
//  AlertsView.swift
//  AnandaAI
//
//  Created by Diya Maria on 24/09/24.
//

import SwiftUI

struct AlertsView: View {
    @State private var schedules: [Schedule] = []
    @State private var isLoading = true
    @State private var errorMessage: String?
    
    var body: some View {
        VStack {
            if isLoading {
                ProgressView("Loading schedules...")
            } else if let errorMessage = errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
            } else {
                List(schedules) { schedule in
                    Text("\(schedule.patientName) needs to take \(schedule.quantity) units of \(schedule.medicineName) at \(schedule.timing)")
                }
            }
        }
        .onAppear {
            fetchSchedules()
        }
    }
    
    private func fetchSchedules() {
        NetworkManager.shared.fetchSchedules { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let fetchedSchedules):
                    self.schedules = fetchedSchedules
                    self.isLoading = false
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }
}

