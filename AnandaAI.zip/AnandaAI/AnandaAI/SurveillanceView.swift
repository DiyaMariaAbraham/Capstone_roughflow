//
//  SurveillanceView.swift
//  AnandaAI
//
//  Created by Diya Maria on 24/09/24.
//
import SwiftUI

struct SurveillanceView: View {
    var body: some View {
        Text("Surveillance Feed")
            .font(.largeTitle)
            .navigationBarTitle("Surveillance", displayMode: .inline)
    }
}

struct SurveillanceView_Previews: PreviewProvider {
    static var previews: some View {
        SurveillanceView()
    }
}

