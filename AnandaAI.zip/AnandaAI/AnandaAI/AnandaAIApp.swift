//
//  AnandaAIApp.swift
//  AnandaAI
//
//  Created by Diya Maria on 20/09/24.
//

import SwiftUI

@main
struct AnandaAIApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}

