//import SwiftUI
//
//struct Medication: Identifiable {
//    var id = UUID()
//    var name: String
//    var time: Date
//}
//
//struct ProfileView: View {
//    @State private var patientName: String = ""
//    @State private var patientAge: String = ""
//    @State private var medications: [Medication] = []
//    @State private var newMedicationName: String = ""
//    @State private var newMedicationTime = Date()
//    @State private var isSaving = false // Loading indicator state
//    
//    var body: some View {
//        NavigationView {
//            ZStack {
//                Color(.systemGray6).edgesIgnoringSafeArea(.all) // Background color
//                
//                Form {
//                    Section(header: Text("Patient Details").font(.headline).foregroundColor(.blue)) {
//                        TextField("Patient Name", text: $patientName)
//                            .padding()
//                            .background(Color(.lightGray))
//                            .cornerRadius(10)
//                        
//                        TextField("Patient Age", text: $patientAge)
//                            .padding()
//                            .keyboardType(.numberPad)
//                            .background(Color(.lightGray))
//                            .cornerRadius(10)
//                    }
//                    
//                    Section(header: Text("Medications").font(.headline).foregroundColor(.blue)) {
//                        List {
//                            ForEach(medications) { medication in
//                                VStack(alignment: .leading) {
//                                    Text(medication.name)
//                                        .font(.headline)
//                                        .foregroundColor(.primary)
//                                    Text("Time: \(medication.time, formatter: timeFormatter)")
//                                        .font(.subheadline)
//                                        .foregroundColor(.secondary)
//                                }
//                                .padding()
//                                .background(Color(.systemGray5))
//                                .cornerRadius(10)
//                            }
//                            .onDelete(perform: removeMedication)
//                        }
//                        
//                        HStack {
//                            TextField("Medication Name", text: $newMedicationName)
//                                .padding()
//                                .background(Color(.white))
//                                .cornerRadius(10)
//                            
//                            DatePicker("", selection: $newMedicationTime, displayedComponents: .hourAndMinute)
//                                .labelsHidden()
//                            
//                            Button(action: addMedication) {
//                                Image(systemName: "plus.circle.fill")
//                                    .foregroundColor(.green)
//                                    .font(.title)
//                            }
//                        }
//                        .padding(.vertical, 10)
//                    }
//                    
//                    // Save Button
//                    Button(action: savePatientDetails) {
//                        Text(isSaving ? "Saving..." : "Save Details")
//                            .foregroundColor(.white)
//                            .padding()
//                            .frame(width: 250)
//                            .background(isSaving ? Color.gray : Color.blue)
//                            .cornerRadius(10)
//                            .disabled(isSaving) // Disable button while saving
//                    }
//                    .padding()
//                }
//            }
//            .navigationTitle("Patient Profile")
//        }
//    }
//    
//    func addMedication() {
//        let newMedication = Medication(name: newMedicationName, time: newMedicationTime)
//        medications.append(newMedication)
//        newMedicationName = ""
//    }
//    
//    func removeMedication(at offsets: IndexSet) {
//        medications.remove(atOffsets: offsets)
//    }
//    
//    private var timeFormatter: DateFormatter {
//        let formatter = DateFormatter()
//        formatter.timeStyle = .short
//        return formatter
//    }
//    
//    // Function to save patient details and medications to backend
//    func savePatientDetails() {
//        isSaving = true
//        
//        // 1. Save patient details
//        NetworkManager.shared.addPatient(name: patientName, age: patientAge) { result in
//            switch result {
//            case .success(let patientId):
//                // 2. Save medications for the patient
//                saveMedications(patientId: patientId)
//            case .failure(let error):
//                print("Error saving patient details: \(error)")
//                isSaving = false
//            }
//        }
//    }
//    
//    func saveMedications(patientId: Int) {
//        let dispatchGroup = DispatchGroup()
//        
//        for medication in medications {
//            dispatchGroup.enter()
//            NetworkManager.shared.addMedicine(medicineName: medication.name) { result in
//                switch result {
//                case .success(let medicineId):
//                    // Schedule medicine for the patient
//                    NetworkManager.shared.scheduleMedicine(patientId: patientId, medicineId: medicineId, time: medication.time) { result in
//                        if case .failure(let error) = result {
//                            print("Error scheduling medication: \(error)")
//                        }
//                        dispatchGroup.leave()
//                    }
//                case .failure(let error):
//                    print("Error saving medicine: \(error)")
//                    dispatchGroup.leave()
//                }
//            }
//        }
//        
//        dispatchGroup.notify(queue: .main) {
//            print("All medications saved.")
//            isSaving = false
//        }
//    }
//}

import SwiftUI

struct ProfileView: View {
    @State private var patientID: Int = 1 // Hardcoded for simplicity; replace with dynamic ID
    @State private var name: String = ""
    @State private var age: String = ""
    @State private var isLoading: Bool = true
    @State private var showEditForm: Bool = false
    @State private var message: String = ""

    var body: some View {
        VStack {
            if isLoading {
                ProgressView("Loading...")
            } else if showEditForm {
                Form {
                    Section(header: Text("Patient Details")) {
                        TextField("Name", text: $name)
                        TextField("Age", text: $age)
                            .keyboardType(.numberPad)
                    }
                    
                    Button(action: {
                        savePatientDetails()
                    }) {
                        Text("Save Details")
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                }
            } else {
                Text("Patient Profile")
                    .font(.largeTitle)
                
                Text("Name: \(name)")
                Text("Age: \(age)")
                
                Button(action: {
                    showEditForm = true
                }) {
                    Text("Edit Details")
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
        }
        .onAppear {
            fetchPatientDetails()
        }
        .alert(isPresented: .constant(!message.isEmpty)) {
            Alert(title: Text("Message"), message: Text(message), dismissButton: .default(Text("OK")))
        }
    }

    func fetchPatientDetails() {
        guard let url = URL(string: "http://localhost:5000/get_patient/\(patientID)") else {
            message = "Invalid URL"
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                DispatchQueue.main.async {
                    self.isLoading = false
                    self.showEditForm = true // If there's an error, assume patient doesn't exist
                }
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                let jsonDecoder = JSONDecoder()
                if let patient = try? jsonDecoder.decode(Patient.self, from: data) {
                    DispatchQueue.main.async {
                        self.name = patient.name
                        self.age = "\(patient.age)"
                        self.isLoading = false
                        self.showEditForm = false
                    }
                }
            } else {
                DispatchQueue.main.async {
                    self.isLoading = false
                    self.showEditForm = true // Patient not found, show form to add
                }
            }
        }.resume()
    }

    func savePatientDetails() {
        guard let url = URL(string: "http://localhost:5000/add_or_update_patient") else {
            message = "Invalid URL"
            return
        }
        
        let patientData: [String: Any] = ["patient_id": patientID, "name": name, "age": age]
        guard let jsonData = try? JSONSerialization.data(withJSONObject: patientData, options: []) else {
            message = "Failed to serialize data"
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                DispatchQueue.main.async {
                    message = "Failed to save data"
                }
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 201 {
                DispatchQueue.main.async {
                    message = "Details saved successfully"
                    showEditForm = false
                }
            } else {
                DispatchQueue.main.async {
                    message = "Failed to save details"
                }
            }
        }.resume()
    }
}

struct Patient: Codable {
    let patient_id: Int
    let name: String
    let age: Int
}
