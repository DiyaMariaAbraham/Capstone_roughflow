import Foundation

class NetworkManager {
    
    static let shared = NetworkManager()
    private init() {}
    
    // Add patient details
    func addPatient(name: String, age: String, completion: @escaping (Result<Int, Error>) -> Void) {
        guard let url = URL(string: "http://10.14.146.137:5000/add_patient") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "name": name,
            "age": age
        ]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else { return }
            if let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Int],
               let patientId = json["patient_id"] {
                completion(.success(patientId))
            } else {
                completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid response"])))
            }
        }.resume()
    }
    
    // Add medicine
    func addMedicine(medicineName: String, completion: @escaping (Result<Int, Error>) -> Void) {
        guard let url = URL(string: "http://10.14.146.137:5000/add_medicine") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "medicine_name": medicineName
        ]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else { return }
            if let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Int],
               let medicineId = json["medicine_id"] {
                completion(.success(medicineId))
            } else {
                completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid response"])))
            }
        }.resume()
    }
    
    // Schedule medicine
    func scheduleMedicine(patientId: Int, medicineId: Int, time: Date, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let url = URL(string: "http://10.14.146.137:5000/schedule") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        let timeString = formatter.string(from: time)
        
        let body: [String: Any] = [
            "patient_id": patientId,
            "medicine_id": medicineId,
            "timing": timeString,
            "quantity": 1  // Assuming quantity is 1 for now
        ]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            completion(.success(()))
        }.resume()
    }
    
    // Fetch schedules (added this function)
    func fetchSchedules(completion: @escaping (Result<[Schedule], Error>) -> Void) {
        guard let url = URL(string: "http://10.14.146.137:5000/get_schedules") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "No data received"])))
                return
            }
            
            do {
                let schedules = try JSONDecoder().decode([Schedule].self, from: data)
                completion(.success(schedules))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
}
